package Clases;

public class multiplica {
	
	public static int[] multiplica(int[] inArray1, int[] inArray2) {
		int maxLong = inArray1.length > inArray2.length? inArray1.length : inArray2.length;
		int[] res = new int [maxLong];
		
 		if(inArray1.length == inArray2.length) {
			for (int i = 0; i < inArray1.length; i++) {
				res[i] = inArray1[i] * inArray2[i];
			}
		}
 		else {
 			boolean primero = true;
 			int minLong = 0;
 			if(inArray1.length > inArray2.length) {
 				minLong = inArray2.length;
 				
 			}
 			else {
 				primero = false;
 				minLong = inArray1.length;
 			}
 			for (int i = 0; i < maxLong; i++) {
 				if(i < minLong) {
					res[i] = inArray1[i] * inArray2[i];
 				}
 				else {
 					if(primero) {
 						res[i] = inArray1[i];
 					}
 					else {
 						res[i] = inArray2[i];
 					}
 				}
					
			}

 		}
	return res;
	}
}
