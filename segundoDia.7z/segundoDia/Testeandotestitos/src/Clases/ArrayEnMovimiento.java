package Clases;

public class ArrayEnMovimiento {
	
	public ArrayEnMovimiento(){
		super();
	}

	public static int[] moverUno(int[] inArray) {
		int i = inArray.length - 1;
		for(;i > 0;  i-- )
			inArray[i] = inArray[i - 1];
		
		if(inArray.length > 0)
			inArray[0] = -1;
		return inArray;
	}
}
