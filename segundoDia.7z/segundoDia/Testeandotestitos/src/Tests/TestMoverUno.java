package Tests;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.jupiter.api.Test;


import Clases.ArrayEnMovimiento;


class TestMoverUno {

	ArrayEnMovimiento Aem;
	
	
	@Before
	public void setUp() {


	}
	@After 
	@Test
	void test1() {
		int[] array1 = {0, 1 , 2, 3};
		array1 = ArrayEnMovimiento.moverUno(array1);
		assertEquals(-1, array1[0]);
		assertEquals(0, array1[1]);
		assertEquals(1, array1[2]);
		assertEquals(2, array1[3]);
		
		//assertEquals(arrayExp.equals(Aem.moverUno(array1)));
	}
	
	@Test
	void test2() {
		int[] array2 = {0};
	}

	@Test
	void test() {
		int[] array3 = {};
	}
/*
 * 	@Test
	public void testSetRate() {
		EUR.setRate(1.2);
		assertEquals(EUR.getRate(), (Double)(1.2));
	}
*/

}
